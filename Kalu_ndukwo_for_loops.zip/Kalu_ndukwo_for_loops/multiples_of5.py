def multiplesof5(y):
    for multiple in range(0 , y+5 , 5):
         print(multiple)

multiplesof5(1000)
