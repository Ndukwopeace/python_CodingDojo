def basic(y):
    for integer in range(y+1):
        print(f'{integer}')

basic(150)