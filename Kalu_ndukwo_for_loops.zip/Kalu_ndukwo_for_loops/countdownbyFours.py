for i in range (2018 , 0 , -4):
    if i >= 0:
        print(i)